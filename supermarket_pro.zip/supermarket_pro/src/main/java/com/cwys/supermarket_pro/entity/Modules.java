package com.cwys.supermarket_pro.entity;

/*
 * 模块
 */

public class Modules {

	private Integer mId;
	private String moduleName;
	private String moduleRemark;
	private String path;
	private Integer parentId;
	private Integer Weight;
	public Integer getmId() {
		return mId;
	}
	public void setmId(Integer mId) {
		this.mId = mId;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getModuleRemark() {
		return moduleRemark;
	}
	public void setModuleRemark(String moduleRemark) {
		this.moduleRemark = moduleRemark;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	public Integer getWeight() {
		return Weight;
	}
	public void setWeight(Integer weight) {
		Weight = weight;
	}
	public Modules(Integer mId, String moduleName, String moduleRemark, String path, Integer parentId, Integer weight) {
		super();
		this.mId = mId;
		this.moduleName = moduleName;
		this.moduleRemark = moduleRemark;
		this.path = path;
		this.parentId = parentId;
		Weight = weight;
	}
	public Modules() {
		super();
	}
	
}
