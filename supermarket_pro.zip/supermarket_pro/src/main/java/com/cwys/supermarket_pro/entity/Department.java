package com.cwys.supermarket_pro.entity;

/**
 * 部门
 */

public class Department {

	private Integer depId;
	private String depName;
	private Integer parentÍd;
	private Integer depNum;
	private String depRemark;
	public Integer getDepId() {
		return depId;
	}
	public void setDepId(Integer depId) {
		this.depId = depId;
	}
	public String getDepName() {
		return depName;
	}
	public void setDepName(String depName) {
		this.depName = depName;
	}
	public Integer getParentÍd() {
		return parentÍd;
	}
	public void setParentÍd(Integer parentÍd) {
		this.parentÍd = parentÍd;
	}
	public Integer getDepNum() {
		return depNum;
	}
	public void setDepNum(Integer depNum) {
		this.depNum = depNum;
	}
	public String getDepRemark() {
		return depRemark;
	}
	public void setDepRemark(String depRemark) {
		this.depRemark = depRemark;
	}
	public Department(Integer depId, String depName, Integer parentÍd, Integer depNum, String depRemark) {
		super();
		this.depId = depId;
		this.depName = depName;
		this.parentÍd = parentÍd;
		this.depNum = depNum;
		this.depRemark = depRemark;
	}
	public Department() {
		super();
	}
	@Override
	public String toString() {
		return "Department [depId=" + depId + ", depName=" + depName + ", parentÍd=" + parentÍd + ", depNum=" + depNum
				+ ", depRemark=" + depRemark + "]";
	}
	
}
