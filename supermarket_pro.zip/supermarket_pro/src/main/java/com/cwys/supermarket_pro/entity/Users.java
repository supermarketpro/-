package com.cwys.supermarket_pro.entity;

import java.util.Date;
/*
 * 用户
 */
public class Users {

	private Integer userId;
	private Integer depId;
	private String userLoginName;
	private Integer userSex;
	private String userPhone;
	private String userEmail;
	private String userPassWord;
	private Integer userPassWordCount;
	private Integer userIsLock;
	private Date userCreateTime;
	private Date userUpdateTime;
	private String lastLoginIp;
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getDepId() {
		return depId;
	}
	public void setDepId(Integer depId) {
		this.depId = depId;
	}
	public String getUserLoginName() {
		return userLoginName;
	}
	public void setUserLoginName(String userLoginName) {
		this.userLoginName = userLoginName;
	}
	public Integer getUserSex() {
		return userSex;
	}
	public void setUserSex(Integer userSex) {
		this.userSex = userSex;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserPassWord() {
		return userPassWord;
	}
	public void setUserPassWord(String userPassWord) {
		this.userPassWord = userPassWord;
	}
	public Integer getUserPassWordCount() {
		return userPassWordCount;
	}
	public void setUserPassWordCount(Integer userPassWordCount) {
		this.userPassWordCount = userPassWordCount;
	}
	public Integer getUserIsLock() {
		return userIsLock;
	}
	public void setUserIsLock(Integer userIsLock) {
		this.userIsLock = userIsLock;
	}
	public Date getUserCreateTime() {
		return userCreateTime;
	}
	public void setUserCreateTime(Date userCreateTime) {
		this.userCreateTime = userCreateTime;
	}
	public Date getUserUpdateTime() {
		return userUpdateTime;
	}
	public void setUserUpdateTime(Date userUpdateTime) {
		this.userUpdateTime = userUpdateTime;
	}
	public String getLastLoginIp() {
		return lastLoginIp;
	}
	public void setLastLoginIp(String lastLoginIp) {
		this.lastLoginIp = lastLoginIp;
	}
	public Users(Integer userId, Integer depId, String userLoginName, Integer userSex, String userPhone,
			String userEmail, String userPassWord, Integer userPassWordCount, Integer userIsLock, Date userCreateTime,
			Date userUpdateTime, String lastLoginIp) {
		super();
		this.userId = userId;
		this.depId = depId;
		this.userLoginName = userLoginName;
		this.userSex = userSex;
		this.userPhone = userPhone;
		this.userEmail = userEmail;
		this.userPassWord = userPassWord;
		this.userPassWordCount = userPassWordCount;
		this.userIsLock = userIsLock;
		this.userCreateTime = userCreateTime;
		this.userUpdateTime = userUpdateTime;
		this.lastLoginIp = lastLoginIp;
	}
	public Users() {
		super();
	}
	@Override
	public String toString() {
		return "Users [userId=" + userId + ", depId=" + depId + ", userLoginName=" + userLoginName + ", userSex="
				+ userSex + ", userPhone=" + userPhone + ", userEmail=" + userEmail + ", userPassWord=" + userPassWord
				+ ", userPassWordCount=" + userPassWordCount + ", userIsLock=" + userIsLock + ", userCreateTime="
				+ userCreateTime + ", userUpdateTime=" + userUpdateTime + ", lastLoginIp=" + lastLoginIp + "]";
	}
	
}
