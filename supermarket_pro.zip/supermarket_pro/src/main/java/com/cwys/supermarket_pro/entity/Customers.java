package com.cwys.supermarket_pro.entity;

/*
 * 客户代理商
 */

public class Customers {

	private Integer cId;
	private String cName;
	private String cEmail;
	private String cAddress;
	private String cTel;
	private String sBank;
	private String sBankRemark;
	private String cRemark;
	public Integer getcId() {
		return cId;
	}
	public void setcId(Integer cId) {
		this.cId = cId;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcEmail() {
		return cEmail;
	}
	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}
	public String getcAddress() {
		return cAddress;
	}
	public void setcAddress(String cAddress) {
		this.cAddress = cAddress;
	}
	public String getcTel() {
		return cTel;
	}
	public void setcTel(String cTel) {
		this.cTel = cTel;
	}
	public String getsBank() {
		return sBank;
	}
	public void setsBank(String sBank) {
		this.sBank = sBank;
	}
	public String getsBankRemark() {
		return sBankRemark;
	}
	public void setsBankRemark(String sBankRemark) {
		this.sBankRemark = sBankRemark;
	}
	public String getcRemark() {
		return cRemark;
	}
	public void setcRemark(String cRemark) {
		this.cRemark = cRemark;
	}
	public Customers(Integer cId, String cName, String cEmail, String cAddress, String cTel, String sBank,
			String sBankRemark, String cRemark) {
		super();
		this.cId = cId;
		this.cName = cName;
		this.cEmail = cEmail;
		this.cAddress = cAddress;
		this.cTel = cTel;
		this.sBank = sBank;
		this.sBankRemark = sBankRemark;
		this.cRemark = cRemark;
	}
	public Customers() {
		super();
	}
	@Override
	public String toString() {
		return "Customers [cId=" + cId + ", cName=" + cName + ", cEmail=" + cEmail + ", cAddress=" + cAddress
				+ ", cTel=" + cTel + ", sBank=" + sBank + ", sBankRemark=" + sBankRemark + ", cRemark=" + cRemark + "]";
	}
	
}
