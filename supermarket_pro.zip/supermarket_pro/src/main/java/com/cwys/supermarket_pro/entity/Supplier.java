package com.cwys.supermarket_pro.entity;

import java.util.Date;
/*
 * 供货商
 */
public class Supplier {

	private Integer supplierId;
	private String sPersonName;
	private String sName;
	private String sAddress;
	private String eEmail;
	private Date sCreateTime;
	private String sTel;
	private String sRemark;
	private String sBank;
	private String sBankRemark;
	public Integer getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(Integer supplierId) {
		this.supplierId = supplierId;
	}
	public String getsPersonName() {
		return sPersonName;
	}
	public void setsPersonName(String sPersonName) {
		this.sPersonName = sPersonName;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getsAddress() {
		return sAddress;
	}
	public void setsAddress(String sAddress) {
		this.sAddress = sAddress;
	}
	public String geteEmail() {
		return eEmail;
	}
	public void seteEmail(String eEmail) {
		this.eEmail = eEmail;
	}
	public Date getsCreateTime() {
		return sCreateTime;
	}
	public void setsCreateTime(Date sCreateTime) {
		this.sCreateTime = sCreateTime;
	}
	public String getsTel() {
		return sTel;
	}
	public void setsTel(String sTel) {
		this.sTel = sTel;
	}
	public String getsRemark() {
		return sRemark;
	}
	public void setsRemark(String sRemark) {
		this.sRemark = sRemark;
	}
	public String getsBank() {
		return sBank;
	}
	public void setsBank(String sBank) {
		this.sBank = sBank;
	}
	public String getsBankRemark() {
		return sBankRemark;
	}
	public void setsBankRemark(String sBankRemark) {
		this.sBankRemark = sBankRemark;
	}
	public Supplier(Integer supplierId, String sPersonName, String sName, String sAddress, String eEmail,
			Date sCreateTime, String sTel, String sRemark, String sBank, String sBankRemark) {
		super();
		this.supplierId = supplierId;
		this.sPersonName = sPersonName;
		this.sName = sName;
		this.sAddress = sAddress;
		this.eEmail = eEmail;
		this.sCreateTime = sCreateTime;
		this.sTel = sTel;
		this.sRemark = sRemark;
		this.sBank = sBank;
		this.sBankRemark = sBankRemark;
	}
	public Supplier() {
		super();
	}
	@Override
	public String toString() {
		return "Supplier [supplierId=" + supplierId + ", sPersonName=" + sPersonName + ", sName=" + sName
				+ ", sAddress=" + sAddress + ", eEmail=" + eEmail + ", sCreateTime=" + sCreateTime + ", sTel=" + sTel
				+ ", sRemark=" + sRemark + ", sBank=" + sBank + ", sBankRemark=" + sBankRemark + "]";
	}
	
	
}
