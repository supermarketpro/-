package com.cwys.supermarket_pro.entity;

import java.util.Date;

/*
 * 商品
 */

public class Products {

	private Integer proId;
	private Integer cateId;
	private String proName;
	private String proNetContent;
	private Integer proSize;
	private String proBrand;
	private String proTaste;
	private String proDegree;
	private String proOrigin;
	private String proPacking;
	private String proStorage;
	private String proPicUrl;
	private String proTax;
	private Integer proIsSugar;
	private String proNameName;
	private Double proPrice;
	private Double proTradePrice;
	private String proMaxStock;
	private String proMinStock;
	private String porSuppier;
	private String proRegistration;
	private String proRemark;
	private Date probornDate;
	private String proShelf;
	private String proNewUpadteName;
	public Integer getProId() {
		return proId;
	}
	public void setProId(Integer proId) {
		this.proId = proId;
	}
	public Integer getCateId() {
		return cateId;
	}
	public void setCateId(Integer cateId) {
		this.cateId = cateId;
	}
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public String getProNetContent() {
		return proNetContent;
	}
	public void setProNetContent(String proNetContent) {
		this.proNetContent = proNetContent;
	}
	public Integer getProSize() {
		return proSize;
	}
	public void setProSize(Integer proSize) {
		this.proSize = proSize;
	}
	public String getProBrand() {
		return proBrand;
	}
	public void setProBrand(String proBrand) {
		this.proBrand = proBrand;
	}
	public String getProTaste() {
		return proTaste;
	}
	public void setProTaste(String proTaste) {
		this.proTaste = proTaste;
	}
	public String getProDegree() {
		return proDegree;
	}
	public void setProDegree(String proDegree) {
		this.proDegree = proDegree;
	}
	public String getProOrigin() {
		return proOrigin;
	}
	public void setProOrigin(String proOrigin) {
		this.proOrigin = proOrigin;
	}
	public String getProPacking() {
		return proPacking;
	}
	public void setProPacking(String proPacking) {
		this.proPacking = proPacking;
	}
	public String getProStorage() {
		return proStorage;
	}
	public void setProStorage(String proStorage) {
		this.proStorage = proStorage;
	}
	public String getProPicUrl() {
		return proPicUrl;
	}
	public void setProPicUrl(String proPicUrl) {
		this.proPicUrl = proPicUrl;
	}
	public String getProTax() {
		return proTax;
	}
	public void setProTax(String proTax) {
		this.proTax = proTax;
	}
	public Integer getProIsSugar() {
		return proIsSugar;
	}
	public void setProIsSugar(Integer proIsSugar) {
		this.proIsSugar = proIsSugar;
	}
	public String getProNameName() {
		return proNameName;
	}
	public void setProNameName(String proNameName) {
		this.proNameName = proNameName;
	}
	public Double getProPrice() {
		return proPrice;
	}
	public void setProPrice(Double proPrice) {
		this.proPrice = proPrice;
	}
	public Double getProTradePrice() {
		return proTradePrice;
	}
	public void setProTradePrice(Double proTradePrice) {
		this.proTradePrice = proTradePrice;
	}
	public String getProMaxStock() {
		return proMaxStock;
	}
	public void setProMaxStock(String proMaxStock) {
		this.proMaxStock = proMaxStock;
	}
	public String getProMinStock() {
		return proMinStock;
	}
	public void setProMinStock(String proMinStock) {
		this.proMinStock = proMinStock;
	}
	public String getPorSuppier() {
		return porSuppier;
	}
	public void setPorSuppier(String porSuppier) {
		this.porSuppier = porSuppier;
	}
	public String getProRegistration() {
		return proRegistration;
	}
	public void setProRegistration(String proRegistration) {
		this.proRegistration = proRegistration;
	}
	public String getProRemark() {
		return proRemark;
	}
	public void setProRemark(String proRemark) {
		this.proRemark = proRemark;
	}
	public Date getProbornDate() {
		return probornDate;
	}
	public void setProbornDate(Date probornDate) {
		this.probornDate = probornDate;
	}
	public String getProShelf() {
		return proShelf;
	}
	public void setProShelf(String proShelf) {
		this.proShelf = proShelf;
	}
	public String getProNewUpadteName() {
		return proNewUpadteName;
	}
	public void setProNewUpadteName(String proNewUpadteName) {
		this.proNewUpadteName = proNewUpadteName;
	}
	public Products(Integer proId, Integer cateId, String proName, String proNetContent, Integer proSize,
			String proBrand, String proTaste, String proDegree, String proOrigin, String proPacking, String proStorage,
			String proPicUrl, String proTax, Integer proIsSugar, String proNameName, Double proPrice,
			Double proTradePrice, String proMaxStock, String proMinStock, String porSuppier, String proRegistration,
			String proRemark, Date probornDate, String proShelf, String proNewUpadteName) {
		super();
		this.proId = proId;
		this.cateId = cateId;
		this.proName = proName;
		this.proNetContent = proNetContent;
		this.proSize = proSize;
		this.proBrand = proBrand;
		this.proTaste = proTaste;
		this.proDegree = proDegree;
		this.proOrigin = proOrigin;
		this.proPacking = proPacking;
		this.proStorage = proStorage;
		this.proPicUrl = proPicUrl;
		this.proTax = proTax;
		this.proIsSugar = proIsSugar;
		this.proNameName = proNameName;
		this.proPrice = proPrice;
		this.proTradePrice = proTradePrice;
		this.proMaxStock = proMaxStock;
		this.proMinStock = proMinStock;
		this.porSuppier = porSuppier;
		this.proRegistration = proRegistration;
		this.proRemark = proRemark;
		this.probornDate = probornDate;
		this.proShelf = proShelf;
		this.proNewUpadteName = proNewUpadteName;
	}
	public Products() {
		super();
	}
	@Override
	public String toString() {
		return "Products [proId=" + proId + ", cateId=" + cateId + ", proName=" + proName + ", proNetContent="
				+ proNetContent + ", proSize=" + proSize + ", proBrand=" + proBrand + ", proTaste=" + proTaste
				+ ", proDegree=" + proDegree + ", proOrigin=" + proOrigin + ", proPacking=" + proPacking
				+ ", proStorage=" + proStorage + ", proPicUrl=" + proPicUrl + ", proTax=" + proTax + ", proIsSugar="
				+ proIsSugar + ", proNameName=" + proNameName + ", proPrice=" + proPrice + ", proTradePrice="
				+ proTradePrice + ", proMaxStock=" + proMaxStock + ", proMinStock=" + proMinStock + ", porSuppier="
				+ porSuppier + ", proRegistration=" + proRegistration + ", proRemark=" + proRemark + ", probornDate="
				+ probornDate + ", proShelf=" + proShelf + ", proNewUpadteName=" + proNewUpadteName + "]";
	}

	
}
